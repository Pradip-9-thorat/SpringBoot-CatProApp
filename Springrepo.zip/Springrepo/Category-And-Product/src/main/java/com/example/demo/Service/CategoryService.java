package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.Repository.CategoryRepository;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository catRepo;

    // Get all categories with pagination
    public Page<Category> getAllCategories(int page) {
        return catRepo.findAll(PageRequest.of(page, 10));
    }

    // Create a new category
    public Category createCategory(Category category) {
        return catRepo.save(category);
    }

    // Get category by ID
    public Category getCategoryById(Long id) {
        return catRepo.findById(id).orElse(null);
    }

    // Update category by ID
    public Category updateCategory(Long id, Category categoryDetails) {
        Category category = catRepo.findById(id).orElse(null);
        if (category != null) {
            category.setName(categoryDetails.getName());
            return catRepo.save(category);
        }
        return null;
    }

    // Delete category by ID
    public void deleteCategory(Long id) {
    	catRepo.deleteById(id);
    }
}
package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Product;
import com.example.demo.Repository.ProductRepository;


@Service
public class ProductService {

    @Autowired
    private ProductRepository proRepo;

    // Get all products with pagination
    public Page<Product> getAllProducts(int page) {
        return proRepo.findAll(PageRequest.of(page, 10));
    }

    // Create a new product
    public Product createProduct(Product product) {
        return proRepo.save(product);
    }

    // Get product by ID
    public Product getProductById(Long id) {
        return proRepo.findById(id).orElse(null);
    }

    // Update product by ID
    public Product updateProduct(Long id, Product productDetails) {
        Product product = proRepo.findById(id).orElse(null);
        if (product != null) {
            product.setName(productDetails.getName());
            product.setPrice(productDetails.getPrice());
            return proRepo.save(product);
        }
        return null;
    }

    // Delete product by ID
    public void deleteProduct(Long id) {
    	proRepo.deleteById(id);
    }
}
